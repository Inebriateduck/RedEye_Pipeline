# ---- RedEye Launcher ----
# Edit these three lines only


INPUT      <- "C:\\Users\\awsms\\Downloads\\Testin"
OUTPUT     <- "C:\\Users\\awsms\\Downloads\\testoutput"
SYKO       <- TRUE
BATCH_SIZE <- 100
CORES      <- parallel::detectCores() - 2


#==============================================================================#
#========================# Sourcing - Don't touch!!!! =========================#
#==============================================================================#

source(file.path(dirname(normalizePath(sys.frames()[[1]]$ofile)), "Director.R"))
